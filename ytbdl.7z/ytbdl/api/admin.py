from django.contrib import admin
from .models import Resolve

admin.site.register(Resolve, )
