from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('resolve', views.api.resolve, name='resolve'),
    path('quality', views.api.quality, name='quality'),
    path('download', views.api.download, name='download'),
    path('progress', views.api.progress, name='progress'),

]
