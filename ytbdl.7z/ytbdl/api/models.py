import enum
import os
from django.core.validators import RegexValidator
from django.db import models
import django.utils.timezone
import django.db.models.fields
import datetime
from django.db.models import QuerySet
from django.db.models.query_utils import DeferredAttribute

import common.utils


class Resolve(models.Model):
    rid = models.CharField(max_length=11, unique=True, db_index=True, primary_key=True, null=False, blank=False, )
    data = models.TextField(null=False, blank=False, )
    added_time = models.DateTimeField(auto_now_add=True)

    @classmethod
    def get_unique_id(cls):
        i = common.utils.generate_random_id(cls.rid.field.max_length)
        while cls.objects.filter(rid=i).exists():
            i = common.utils.generate_random_id(cls.rid.field.max_length)
        return i
