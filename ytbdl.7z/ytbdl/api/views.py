import ast
import datetime
import logging
import os
import random
import shutil
import subprocess
from pprint import pprint
from queue import Queue, Empty
import re
import threading
import time

import requests
from cffi.cparser import lock
from django.core.handlers.wsgi import WSGIRequest
from django.db.models.expressions import result
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, reverse
import yt_dlp
from django.utils import functional, timezone

import common.utils

loger = logging.getLogger(__name__)


class Logger(object):
    def debug(self, msg):
        loger.info(msg, )

    def warning(self, msg):
        loger.info(msg, )

    def error(self, msg):
        loger.info(msg, )

    def info(self, msg):
        loger.info(msg, )


class api:
    @staticmethod
    def resolve(request: WSGIRequest):
        vid = request.GET.get("vid", default=None)
        if not vid: return JsonResponse({}, status=400)

        from ytbdl import settings

        try:
            _test_file = "./resource/test_api_resolve.txt"
            if os.path.isfile(_test_file) and settings.DEBUG:
                with open(_test_file, "r") as f:
                    r = ast.literal_eval(f.read())
            else:
                from down import views
                ydl_opts = {
                    "noplaylist": True,
                    "nocheckcertificate": True,
                    "http_headers": {
                        'User-Agent': views.requests_session.headers["User-Agent"],
                    },
                    'logger': Logger(),
                }
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    r = ydl.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False, process=False)

                # subprocess.Popen(f'{settings.DB_PATH / "yt-dlp_linux"}')
                # r = ""

            tmpfile = settings.tmp_path / ".".join((r["id"], "info", common.utils.generate_random_id(8), "txt"))
            with open(tmpfile, "w", encoding="utf-8") as f:
                f.write(str(r))

            result = {
                "id": r["id"],
                "title": re.sub(r'[/\\<|>?*:"]', '', r["title"]),
                "description": r["description"],
                "upload_date": r["upload_date"],
                "timestamp": r["timestamp"],
                "webpage_url": r["webpage_url"],
                "channel_id": r["channel_id"],
                "channel_url": r["channel_url"],
                "formats": [],
                "audios": [],
                "qualities": [],
                "thumbnails": [],
                "subtitles": [],
                "_subtitles": [],
            }

            result["title"] = re.sub(r"#", "~", result["title"])  # #导致nginx404
            
            if len(result["title"].encode("utf8"))>200:
                new_title,i = "",0
                while len(new_title.encode("utf8"))<200:
                    new_title = result["title"][:i]
                    i+=1
                result["title"] = new_title+"..."

            # re.sub(r'[/\\<|>?*:"]', '',  info['title'] + '-' + info['id'] + '-' + info['format_note'])
            for i in r["formats"]:  # 列出所有的格式
                d = {"type": "", }
                for _ in [
                    "url",
                    "ext",
                    "filesize",
                    "format_id",
                    "format_note",
                    "protocol",
                    "fps",
                    "width",
                    "height",
                    "asr",
                    "audio_channels",
                ]:
                    d[_] = i.get(_, "undefined")

                if not isinstance(d["filesize"], int):
                    d["filesize"] = i.get("filesize_approx", "undefined")

                if "asr" in i and i["asr"] is not None and "audio_channels" in i and i["audio_channels"] is not None and \
                        "fps" in i and i["fps"] is not None and "height" in i and i["height"] is not None:  # 视频音频
                    d["type"] = "va"
                elif "fps" in i and i["fps"] is not None and "height" in i and i["height"] is not None:  # 仅视频
                    d["type"] = "v"
                elif "asr" in i and i["asr"] is not None and "audio_channels" in i and i[
                    "audio_channels"] is not None:  # 仅音频
                    d["type"] = "a"

                if d["type"] in ["va", "v", ] and isinstance(d["height"], int):
                    if not isinstance(d["width"], int):
                        d["width"] = 0
                    if d["format_note"] == "undefined":
                        d["format_note"] = f'{d["height"]}p'
                    if "m3u8" in d["protocol"]:
                        d["ext"] = "m3u8"
                        d["type"] = "va"
                    if not isinstance(d["filesize"], int):
                        d["filesize"] = 1

                result['formats'].append(d)

            # 列出所有的封面
            for i in r["thumbnails"]:
                if "height" in i and isinstance(i["height"], int) and "width" in i and isinstance(i["width"], int):
                    d = {
                        "width": i["width"],
                        "height": i["height"],
                        "url": i["url"],
                    }
                    result["thumbnails"].append(d)
            result["thumbnails"].sort(key=lambda i: i["width"] * i["height"])

            # 列出所有的字幕
            subtitles = []
            if 'subtitles' in r:
                sub_ = list(r['subtitles'].items())
                subtitles.extend(sub_)
            if 'automatic_captions' in r:
                sub_ = list(r['automatic_captions'].items())
                subtitles.extend(sub_)
            # pprint(subtitles)
            lll = []
            for l in subtitles:
                ll1 = re.search('^[A-Za-z]+', l[0])
                ll2 = re.search('^[A-Za-z\-]+', l[0])
                if ll1 and ll2:
                    if "-" in l[0] and not re.search('-orig$', l[0]):  # zh-hant字幕也是英文的
                        continue
                    k = {'code': ll1.group(0).lower(), 'key': ll2.group(0).lower(), 'name': l[0], 'url': None}
                    for kk in l[1]:
                        if kk['ext'] == 'vtt':  # vtt格式下载链接
                            k['url'] = kk['url']
                            lll.append(k)
                            break
            result["subtitles"] = list({(i["code"], i["key"], i["name"]) for i in lll
                                        if (i["url"] is not None and
                                            re.search(r"^(?:zh|en)", i["key"]))})
            result["_subtitles"] = lll
            result["subtitles"] = [{"code": i[0], "key": i[1], "name": i[2]} for i in result["subtitles"]]
            result["subtitles"].sort(key=lambda i: (i["code"], len(i["key"]),), reverse=False)
            # print(result["subtitles"])

            # 列出所有的音频
            audio_i, audio_index = None, -1
            for index, i in enumerate(result["formats"]):
                if i["type"] == "a":
                    if not isinstance(i["filesize"], int) or i["filesize"] <= 0: continue
                    if not i["ext"] in ["m4a", "webm", ]: continue
                    if audio_i is None:
                        audio_i = i
                        audio_index = index
                    result["audios"].append(index)
            if audio_i is None: raise ValueError("No audio format")

            result["audios"].sort(key=lambda i: result["formats"][i]["filesize"])
            audio_index = result["audios"][0]
            audio_i = result["formats"][audio_index]

            from ytbdl import settings
            from common.config import CONFIG
            video_path = settings.STATIC_ROOT / "video"
            if not os.path.isdir(video_path): video_path = settings.STATICFILES_DIRS[2] / "video"

            # 列出所有可选的视频分辨率
            _included_qualities, qids = set(), []
            for index, i in enumerate(result['formats']):
                if i["type"] == "va" or i["type"] == "v":  # "m3u8",
                    if not i["ext"] in ["mp4", "webm", ]: continue
                    if not isinstance(i["format_note"], str) or not re.search(r"^\d+p\d*$", i["format_note"]): continue
                    if not isinstance(i["filesize"], int) or i["filesize"] <= 0: continue
                    if not isinstance(i["width"], int) or not isinstance(i["height"], int): continue
                    wh = (i["type"], i["width"], i["height"], i["ext"],)
                    if wh in _included_qualities: continue
                    _included_qualities.add(wh)
                    qid = common.utils.generate_random_id(10)
                    while qid in qids:
                        qid = common.utils.generate_random_id(10)
                        qids.append(qid)
                    d = {
                        "type": i["type"],
                        "cached": False,
                        "qid": qid,
                        "width": i["width"],
                        "height": i["height"],
                        "video_index": index,
                        # "video_link": i["url"],
                        "video_ext": i["ext"],
                        "size": i["filesize"],
                        "how": "",
                    }
                    if i["type"] == "v":
                        d["audio_index"] = audio_index
                        # d["audio_link"] = audio_i["url"]
                        d["size"] += audio_i["filesize"]

                    from down.core import DownCore

                    video_name = DownCore._format_name(result, d)
                    video_name_path = video_path / video_name
                    if os.path.isfile(video_name_path) and os.path.exists(video_name_path):
                        d["size"] = os.path.getsize(video_name_path)
                        d["cached"] = True

                    result["qualities"].append(d)
            result["qualities"].sort(
                key=lambda i: (not i["cached"], i["type"] != "va", ~i["height"], ~i["width"], i["size"],))

            _all_wh = list({(i["width"], i["height"]) for i in result["qualities"]})
            for i in _all_wh:
                indexs, cached = [], False
                for j in range(len(result["qualities"])):
                    ji = result["qualities"][j]
                    if (ji["width"], ji["height"]) == i:
                        indexs.append(j)
                        if ji["cached"]: cached = True
                if cached:
                    indexs.pop(0)
                    indexs.sort(key=lambda i: i, reverse=True)
                    for j in indexs:
                        result["qualities"].pop(j)

            _quality_type = {
                -1: "省流 ",
                854: "省流",
                1280: "标清",
                1920: "高清",
                2560: "2K",
                3840: "4K",
            }
            _quality_type2 = {v: k for k, v in _quality_type.items()}
            _quality_type2[""] = 999999
            for i in result["qualities"]:
                _width = i["width"]
                if _width in _quality_type and isinstance(_quality_type[_width], str):
                    i["how"] = _quality_type[_width]
                    _quality_type[_width] = (_quality_type[_width],)
                elif i["type"] == "va" and isinstance(_quality_type[-1], str):
                    i["how"] = _quality_type[-1]
                    _quality_type[-1] = (_quality_type[-1],)
            result["qualities"].sort(key=lambda i: (_quality_type2[i["how"]],))

            api._clear_caches()
            from . import models
            d = models.Resolve()
            d.rid = d.get_unique_id()
            d.data = str(result)
            d.save()
            result["rid"] = d.rid

            result.pop("formats")
            result.pop("audios")
            result.pop("thumbnails")
            result.pop("_subtitles")
            return JsonResponse(result, status=200)
        except Exception as e:
            # raise e
            return JsonResponse({"error": str(type(e).__name__) + str(e.args)}, status=500)

    sids = {}
    lock = threading.Lock()

    @staticmethod
    def _clear_caches():
        from api import models
        days_ago = timezone.now() - datetime.timedelta(days=3)
        d = models.Resolve.objects.filter(added_time__lte=days_ago)
        d.delete()

    @staticmethod
    def _clear_sess():
        with lock:
            for sid in list(api.sids.keys()):
                if len(api.sids[sid]["error"]) > 0 and time.time() - api.sids[sid]["ended_time"] > 60 * 10:
                    loger.info(f"pop: {sid}, {api.sids[sid]['error']}")
                    api.sids.pop(sid)
                elif api.sids[sid]["finished"] and time.time() - api.sids[sid]["ended_time"] > 60 * 60:
                    loger.info(f"pop: {sid}, finished")
                    api.sids.pop(sid)

            from ytbdl import settings
            video_path = settings.STATIC_ROOT / "video"
            if not os.path.isdir(video_path): video_path = settings.STATICFILES_DIRS[2] / "video"
            for i in os.listdir(video_path):
                path = os.path.join(video_path, i)
                if os.path.isfile(path):
                    if time.time() - os.stat(path).st_mtime > 60 * 60 * 24 * 14:
                        loger.info(f"remove_finished: {path}")
                        os.remove(path)

            for i in os.listdir(settings.log_path):
                path = os.path.join(settings.log_path, i)
                if time.time() - os.stat(path).st_mtime > 60 * 60 * 24 * 20:
                    if os.path.isfile(path):
                        loger.info(f"remove_log: {path}")
                        os.remove(path)

            for i in os.listdir(settings.tmp_path):
                path = os.path.join(settings.tmp_path, i)
                if time.time() - os.stat(path).st_mtime > 60 * 60 * 24 * 1:
                    if os.path.isfile(path):
                        loger.info(f"remove_tmp_file: {path}")
                        os.remove(path)
                    elif os.path.isdir(path):
                        loger.info(f"remove_tmp_dir: {path}")
                        shutil.rmtree(path, ignore_errors=True)

    @staticmethod
    def download(request: WSGIRequest):
        rid = request.GET.get("rid", default=None)
        qid = request.GET.get("qid", default=None)
        if not rid: return JsonResponse({}, status=400)
        if not qid: return JsonResponse({}, status=400)

        from api import models
        d = models.Resolve.objects.get(rid=rid)
        j = ast.literal_eval(d.data)

        quality_info = None
        for i in j["qualities"]:
            if i["qid"] == qid:
                quality_info = i
                break
        if not quality_info: return JsonResponse({}, status=400)

        from down.core import DownCore

        video_name = DownCore._format_name(j, quality_info)
        from ytbdl import settings
        from common.config import CONFIG
        video_path = settings.STATIC_ROOT / "video"
        if os.path.isdir(video_path):
            video_path = video_path / video_name
        else:
            video_path = settings.STATICFILES_DIRS[2] / "video" / video_name
        # print(video_path)
        if os.path.isfile(video_path) and os.path.exists(video_path):
            result = {"cached": True, }
            path = reverse("down:video", kwargs={"name": video_name})
            # if len(CONFIG["direct_download_link_prefix"]) > 0:
            #     result["download_link_direct"] = CONFIG["homepage_link"] + path + "?cdn=no"
            # if len(CONFIG["cf_cdn_download_link_prefix"]) > 0:
            #     result["download_link_cf_cdn"] = CONFIG["homepage_link"] + path + "?cdn=cf"
            # if len(CONFIG["gcore_cdn_download_link_prefix"]) > 0:
            #     result["download_link_gcore_cdn"] = CONFIG["homepage_link"] + path + "?cdn=gcore"
            if len(CONFIG["direct_download_link_prefix"]) > 0:
                result["download_link_direct"] = CONFIG["direct_download_link_prefix"] + path
            if len(CONFIG["cf_cdn_download_link_prefix"]) > 0:
                result["download_link_cf_cdn"] = CONFIG["cf_cdn_download_link_prefix"] + path
            if len(CONFIG["gcore_cdn_download_link_prefix"]) > 0:
                result["download_link_gcore_cdn"] = CONFIG["gcore_cdn_download_link_prefix"] + path
            return JsonResponse(result, status=200)

        api._clear_sess()

        if len(api.sids) > 4096:
            return JsonResponse({"error": f"too many requests, please try later. ({len(api.sids)})"}, status=200)

        sid = common.utils.generate_random_id(12)
        while sid in api.sids: sid = common.utils.generate_random_id(12)
        sess = {
            "sid": sid,
            "rid": rid,
            "qid": qid,
            "video_info": j,
            "quality_info": quality_info,
            "name": video_name,
            "output": video_path,
            "is_waiting": False,
            "progress": 0,
            "totalStep": 4 if "audio_index" in quality_info else 4,
            "finished": False,
            "error": "",
            "ended_time": None,
            "queue": Queue(),
            "thread": threading.Thread(target=DownCore._download_wrapper, args=(sid,), daemon=True, name=sid),
            "thread_video": None,
            "thread_audio": None,
            "worker": [1, 0],
            "downspeed_video": 0,
            "downspeed_audio": 0,
            "filesize_video": 0,
            "filesize_audio": 0,
            "downpart_video": 0,
            "downpart_audio": 0,
        }
        api.sids[sid] = sess
        sess["thread"].start()
        # print(sess)
        return JsonResponse({"sid": sid, }, status=200)

    @staticmethod
    def quality(request: WSGIRequest):
        rid = request.GET.get("rid", default=None)
        qid = request.GET.get("qid", default=None)
        if not rid: return JsonResponse({}, status=400)
        if not qid: return JsonResponse({}, status=400)

        from api import models
        d = models.Resolve.objects.get(rid=rid)
        j = ast.literal_eval(d.data)

        quality_info = None
        for i in j["qualities"]:
            if i["qid"] == qid:
                quality_info = i
                break
        if not quality_info: return JsonResponse({}, status=400)

        result = {}
        info1 = j['formats'][quality_info['video_index']]
        result["video_link"] = info1["url"]
        result["video_ext"] = info1["ext"]
        result["video_size"] = info1["filesize"]
        result["width"] = info1["width"]
        result["height"] = info1["height"]
        if "audio_index" in quality_info:
            info2 = j['formats'][quality_info['audio_index']]
            result["audio_link"] = info2["url"]
            result["audio_ext"] = info2["ext"]
            result["audio_size"] = info2["filesize"]

        return JsonResponse(result, status=200)

    @staticmethod
    def progress(request: WSGIRequest):
        sid = request.GET.get("sid", default=None)
        if not sid: return JsonResponse({}, status=400)
        if sid not in api.sids: return JsonResponse({}, status=404)
        sess = api.sids[sid]

        with api.lock:
            if sess["is_waiting"]:
                sess["is_waiting"] = False
                sess["queue"].put(sess["progress"])

        result = {
            "error": sess["error"],
            "progress": sess["progress"],
            "totalStep": sess["totalStep"],
            "downspeed_video": sess["downspeed_video"],
            "downspeed_audio": sess["downspeed_audio"],
            "filesize_video": sess["filesize_video"],
            "filesize_audio": sess["filesize_audio"],
            "downpart_video": sess["downpart_video"],
            "downpart_audio": sess["downpart_audio"],
            "worker": sess["worker"],
        }

        from common.config import CONFIG

        if sess["finished"]:
            path = reverse("down:video", kwargs={"name": sess["name"]})
            # if len(CONFIG["direct_download_link_prefix"]) > 0:
            #     result["download_link_direct"] = CONFIG["homepage_link"] + path + "?cdn=no"
            # if len(CONFIG["cf_cdn_download_link_prefix"]) > 0:
            #     result["download_link_cf_cdn"] = CONFIG["homepage_link"] + path + "?cdn=cf"
            # if len(CONFIG["gcore_cdn_download_link_prefix"]) > 0:
            #     result["download_link_gcore_cdn"] = CONFIG["homepage_link"] + path + "?cdn=gcore"
            if len(CONFIG["direct_download_link_prefix"]) > 0:
                result["download_link_direct"] = CONFIG["direct_download_link_prefix"] + path
            if len(CONFIG["cf_cdn_download_link_prefix"]) > 0:
                result["download_link_cf_cdn"] = CONFIG["cf_cdn_download_link_prefix"] + path
            if len(CONFIG["gcore_cdn_download_link_prefix"]) > 0:
                result["download_link_gcore_cdn"] = CONFIG["gcore_cdn_download_link_prefix"] + path

        return JsonResponse(result, status=200)
