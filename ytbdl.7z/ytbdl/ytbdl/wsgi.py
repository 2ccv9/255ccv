"""
WSGI config for ytbdl project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.2/howto/deployment/wsgi/
"""

import os
import logging
import stat
import sys
from multiprocessing import current_process
from django.core.wsgi import get_wsgi_application

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ytbdl.settings')

application = get_wsgi_application()
loger = logging.getLogger(__name__)


def recursive_chmod(path, mode):
    for dirpath, dirnames, filenames in os.walk(path):
        os.chmod(dirpath, mode)
        for name in dirnames:
            os.chmod(os.path.join(dirpath, name), mode)
        for name in filenames:
            os.chmod(os.path.join(dirpath, name), mode)


if "UWSGI_ORIGINAL_PROC_NAME" in os.environ:
    loger.info(f"wsgi current_process: {current_process()},{current_process().ident}", )
    loger.info(f"os.environ: {os.environ}", )
    loger.info(f"sys.argv: {sys.argv}", )

    from common.config import CONFIG, CONFIG_PATH

    CONFIG.load()
    CONFIG.sys_argv.extend(sys.argv)
    if os.path.exists(CONFIG_PATH):
        os.chmod(CONFIG_PATH, 0o777)

    from ytbdl import settings

    if os.path.exists(settings.log_path):
        recursive_chmod(settings.log_path, 0o777)
