from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('cover/<str:rid>', views.down.cover, name='cover'),
    path('subtitle/<str:name>', views.down.subtitle, name='subtitle'),
    path('video/<str:name>', views.down.video, name='video'),

]
