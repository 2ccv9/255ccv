import asyncio
import os
import random
import re
import shutil
import subprocess
import threading
import time
import uuid
from queue import Queue, Empty
import asyncio
import base64
import random
import re
import sys
import time
import python_socks
import aiohttp
from aiohttp import ClientSession, ClientConnectorError
import os
from pathlib import Path
from aiohttp_socks import ProxyConnector
import requests

import common.utils
from api.views import api


class ChunkDown:
    def __init__(self, type, loop, sess, url, headers, output, filesize):
        self.type = type
        self.loop: asyncio.BaseEventLoop = loop
        self.sess = sess
        self.url = url
        self.headers = headers
        self.output = output
        self.filesize = filesize
        from ytbdl import settings
        self.temp_dir = settings.tmp_path / (self.type + "-" + uuid.uuid4().hex)
        os.makedirs(self.temp_dir, exist_ok=True)
        self.session: aiohttp.ClientSession = None
        self._totallen, self._totallenlast, self._lastsecond = 0, 0, time.time()

    async def worker(self, rs):
        workername = "part-" + "-".join([str(_) for _ in rs])
        savepath = self.temp_dir / workername
        while True:
            await asyncio.sleep(random.uniform(0, 2.0))
            try:
                a = time.time()
                headers = self.headers.copy()
                headers["Range"] = f"bytes={rs[0]}-"
                if rs[1] != -1: headers["Range"] += str(rs[1])
                async with self.session.get(url=self.url, allow_redirects=True, ssl=False, headers=headers) as response:
                    if response.status == 206:
                        _d = bytearray()
                        while True:
                            chunk = await response.content.read(1024)
                            if not chunk: break
                            _d += chunk
                            self._totallen += len(chunk)
                            self.sess[f"downpart_{self.type}"] = self._totallen
                            _now = time.time()
                            if _now - self._lastsecond >= 1:
                                self._lastsecond = _now
                                self.sess[f"downspeed_{self.type}"] = self._totallen - self._totallenlast
                                self._totallenlast = self._totallen
                        with open(savepath, 'wb') as f:
                            f.write(_d)
                        print(f"{workername} 完成，耗时：{(time.time() - a)}")
                        break
                    else:
                        print(f"{workername} 失败，状态码: {response.status} {self.url}")
            except (
                    asyncio.exceptions.TimeoutError,
                    aiohttp.client_exceptions.ServerDisconnectedError,
                    ConnectionResetError,
                    python_socks._errors.ProxyConnectionError,
                    ClientConnectorError,  # aiohttp.client_exceptions.ClientOSError: [WinError 121] 信号灯超时时间已到
            ) as e:
                if isinstance(e, (ConnectionResetError,)):
                    print(f"{workername} 连接重设，{str(e)}。")
                    await asyncio.sleep(1)
                else:
                    print(f"{workername} 超时，{str(e)}。")
                if os.path.isfile(savepath):
                    os.remove(savepath)
            except:
                if os.path.isfile(savepath):
                    os.remove(savepath)
                raise

        return savepath

    async def run(self):
        self.session = aiohttp.ClientSession(connector=None, timeout=aiohttp.ClientTimeout(total=30, ))
        workers = []
        rss = []
        rs = list(range(0, self.filesize, int(self.filesize / 6)))
        rc = len(rs) - 1
        for i in range(0, rc):
            ars = (rs.pop(0), rs[0] - 1)
            rss.append(ars)
        if rs[0] < self.filesize:
            ars = (rs.pop(0), -1)
            rss.append(ars)
        for i in rss:
            workers.append(asyncio.ensure_future(self.worker(i)))
        print(f"{self.type} apart:", self.filesize, rss)
        if self.type == "video":
            self.sess["worker"][0] = len(rss)
        else:
            self.sess["worker"][1] = len(rss)
        group = asyncio.gather(*workers, return_exceptions=True)
        result = await group
        print(f"{self.type} group result:", result)
        self.sess[f"downspeed_{self.type}"] = 0
        with open(self.output, "wb") as f:
            for i in result:
                with open(i, "rb") as f2:
                    f.write(f2.read())
        shutil.rmtree(self.temp_dir)
        await self.session.close()


class DownCore:
    @staticmethod
    def _format_name(video_info, quality_info):
        # {video_info['formats'][quality_info['video_index']]['ext']}
        return f"{video_info['title']}-{quality_info['width']}x{quality_info['height']}-{video_info['id']}.mp4"

    @staticmethod
    def _download_handle_audio(sess):
        from ytbdl import settings
        print("下载音频", time.time(), )
        tmpfile2 = None
        for i in sess["video_info"]['audios']:
            info2 = sess["video_info"]['formats'][i]
            print(i, info2["ext"], round(info2["filesize"] / 1024 / 1024, 2))
            tmpfile2 = settings.tmp_path / ".".join(
                (sess["video_info"]["id"], "a", common.utils.generate_random_id(8), info2["ext"]))
            print(info2, tmpfile2)
            with open(tmpfile2, "wb") as f:
                try:
                    if sess["ended_time"] is not None:
                        try:
                            sess["requests_session"].close()
                        except Exception:
                            pass
                        return
                    d = sess["requests_session"].get(info2["url"], allow_redirects=True, timeout=20, stream=True)
                    d.raise_for_status()
                except Exception:
                    tmpfile2 = None
                    continue
                if sess["ended_time"] is not None:
                    try:
                        sess["requests_session"].close()
                    except Exception:
                        pass
                    return
                sess["filesize_audio"] = info2["filesize"]
                _totallen, _totallenlast, _lastsecond = 0, 0, time.time()
                for chunk in d.iter_content(chunk_size=4096):
                    if sess["ended_time"] is not None:
                        try:
                            sess["requests_session"].close()
                        except Exception:
                            pass
                        return
                    if chunk:
                        f.write(chunk)
                        _totallen += len(chunk)
                        sess["downpart_audio"] = _totallen
                    _now = time.time()
                    if _now - _lastsecond >= 1:
                        _lastsecond = _now
                        sess["downspeed_audio"] = _totallen - _totallenlast
                        _totallenlast = _totallen
                sess["downspeed_audio"] = 0
            break
        sess["tmpfile2"] = tmpfile2

    @staticmethod
    def _download_handle_video_async(sess, info, tmpfile):
        from ytbdl import settings
        print("下载视频async", time.time(), )
        sess["filesize_video"] = info["filesize"]
        loop = asyncio.new_event_loop()
        headers = {}
        headers.update(sess["requests_session"].headers)
        cd = ChunkDown("video", loop, sess, info["url"], headers, tmpfile, info["filesize"])
        try:
            loop.run_until_complete(cd.run())
        except Exception as e:
            print("video run_until_complete error:", type(e), e.args)
            if os.path.isfile(tmpfile):
                os.remove(tmpfile)
        loop.close()

    @staticmethod
    def _download_handle_audio_async(sess, ):
        from ytbdl import settings
        print("下载音频async", time.time(), )
        loop = asyncio.new_event_loop()
        tmpfile2 = None
        for i in sess["video_info"]['audios']:
            info2 = sess["video_info"]['formats'][i]
            tmpfile2 = settings.tmp_path / ".".join(
                (sess["video_info"]["id"], "a", common.utils.generate_random_id(8), info2["ext"]))
            sess["filesize_audio"] = info2["filesize"]
            headers = {}
            headers.update(sess["requests_session"].headers)
            cd = ChunkDown("audio", loop, sess, info2["url"], headers, tmpfile2, info2["filesize"])
            try:
                loop.run_until_complete(cd.run())
            except Exception as e:
                print("audio run_until_complete error:", type(e), e.args)
                if os.path.isfile(tmpfile2):
                    os.remove(tmpfile2)
                continue
            break
        loop.close()
        sess["tmpfile2"] = tmpfile2

    @staticmethod
    def _download_handle(sess):
        from ytbdl import settings
        from down import views
        requests_session = requests.Session()
        requests_session.verify = False
        requests_session.trust_env = False
        requests_session.headers.update(views.requests_session.headers)
        sess["requests_session"] = requests_session
        if "audio_index" not in sess["quality_info"]:
            _ = yield 1
            print("下载视频", _, time.time())
            info1 = sess["video_info"]['formats'][sess["quality_info"]['video_index']]
            tmpfile1 = settings.tmp_path / ".".join(
                (sess["video_info"]["id"], "v", common.utils.generate_random_id(8), info1["ext"]))
            print(info1, tmpfile1)
            # with open(tmpfile1, "wb") as f:
            #     d = requests_session.get(info1["url"], allow_redirects=True, timeout=20, stream=True)
            #     d.raise_for_status()
            #     sess["filesize_video"] = info1["filesize"]
            #     _totallen, _totallenlast, _lastsecond = 0, 0, time.time()
            #     for chunk in d.iter_content(chunk_size=4096):
            #         if chunk:
            #             f.write(chunk)
            #             _totallen += len(chunk)
            #             sess["downpart_video"] = _totallen
            #         _now = time.time()
            #         if _now - _lastsecond >= 1:
            #             _lastsecond = _now
            #             sess["downspeed_video"] = _totallen - _totallenlast
            #             _totallenlast = _totallen
            #     sess["downspeed_video"] = 0
            sess["thread_video"] = threading.Thread(target=DownCore._download_handle_video_async,
                                                    args=(sess, info1, tmpfile1,), daemon=True,
                                                    name=sess["sid"] + "_video")
            sess["thread_video"].start()
            sess["thread_video"].join()
            if not os.path.exists(tmpfile1):
                raise ValueError("download video failed")
            if info1["ext"] == "mp4":
                if not os.path.exists(sess["output"]):
                    shutil.move(tmpfile1, sess["output"])
            else:
                # _ = yield 3
                print("转格式", _, time.time())
                tmpfile3 = settings.tmp_path / ".".join(
                    (sess["video_info"]["id"], "va", common.utils.generate_random_id(8), "mp4"))
                files_cmd = ' '.join(tuple(map(lambda x: f'-i "{x}"', [tmpfile1, ], )))
                _popen = subprocess.Popen(
                    f'''"{settings.DB_PATH / 'ffmpeg'}" -y {files_cmd} -c copy -f mp4 "{tmpfile3}"''',
                    shell=True, stderr=subprocess.STDOUT, stdout=subprocess.PIPE, stdin=subprocess.PIPE, )
                v = common.utils.chardet_decode(_popen.communicate()[0])
                if re.search(r'ress.+?to.+?stop.+?for.+?hel', v) and not re.search(r'not\sfound|No\ssuch', v):
                    if not os.path.exists(sess["output"]):
                        shutil.move(tmpfile3, sess["output"])
                else:
                    raise ValueError(v)
        else:
            _ = yield 1
            print("下载视频", _, time.time())
            info1 = sess["video_info"]['formats'][sess["quality_info"]['video_index']]
            tmpfile1 = settings.tmp_path / ".".join(
                (sess["video_info"]["id"], "v", common.utils.generate_random_id(8), info1["ext"]))
            print(info1, tmpfile1)
            # with open(tmpfile1, "wb") as f:
            #     sess["tmpfile2"] = None
            #     sess["thread_audio"] = threading.Thread(target=DownCore._download_handle_audio, args=(sess,),
            #                                             daemon=True,
            #                                             name=sess["sid"] + "_audio")
            #     sess["thread_audio"].start()
            #     d = requests_session.get(info1["url"], allow_redirects=True, timeout=20, stream=True)
            #     d.raise_for_status()
            #     try:
            #         sess["thread_audio"].join(random.uniform(2.8, 3.2))
            #     except Exception as e:
            #         pass
            #     sess["filesize_video"] = info1["filesize"]
            #     _totallen, _totallenlast, _lastsecond = 0, 0, time.time()
            #     for chunk in d.iter_content(chunk_size=4096):
            #         if chunk:
            #             f.write(chunk)
            #             _totallen += len(chunk)
            #             sess["downpart_video"] = _totallen
            #         _now = time.time()
            #         if _now - _lastsecond >= 1:
            #             _lastsecond = _now
            #             sess["downspeed_video"] = _totallen - _totallenlast
            #             _totallenlast = _totallen
            #     sess["downspeed_video"] = 0
            sess["tmpfile2"] = None
            sess["thread_audio"] = threading.Thread(target=DownCore._download_handle_audio_async,
                                                    args=(sess,), daemon=True, name=sess["sid"] + "_audio")
            sess["thread_audio"].start()
            sess["thread_video"] = threading.Thread(target=DownCore._download_handle_video_async,
                                                    args=(sess, info1, tmpfile1,), daemon=True,
                                                    name=sess["sid"] + "_video")
            sess["thread_video"].start()
            sess["thread_video"].join()
            if not os.path.exists(tmpfile1):
                raise ValueError("download video failed")

            _ = yield 2
            sess["thread_audio"].join()

            if sess["tmpfile2"] is None or not os.path.exists(sess["tmpfile2"]):
                raise ValueError("download audio failed")

            # _ = yield 3
            print("合并", _, time.time())
            tmpfile3 = settings.tmp_path / ".".join(
                (sess["video_info"]["id"], "va", common.utils.generate_random_id(8), "mp4"))
            files_cmd = ' '.join(tuple(map(lambda x: f'-i "{x}"', [tmpfile1, sess["tmpfile2"], ], )))
            _popen = subprocess.Popen(  # '-c:v', 'copy', '-c:a', 'aac',
                f'''"{settings.DB_PATH / 'ffmpeg'}" -y {files_cmd} -c copy -f mp4 "{tmpfile3}"''',
                shell=True, stderr=subprocess.STDOUT, stdout=subprocess.PIPE, stdin=subprocess.PIPE, )
            v = common.utils.chardet_decode(_popen.communicate()[0])
            if re.search(r'ress.+?to.+?stop.+?for.+?hel', v) and not re.search(r'not\sfound|No\ssuch', v):
                # not re.search(r'\[NULL|Invalid|not\sfound|No\ssuch', v)
                if not os.path.exists(sess["output"]):
                    shutil.move(tmpfile3, sess["output"])
            else:
                raise ValueError(v)
        os.chmod(sess["output"], 0o777)

    @staticmethod
    def _download_wrapper(sid):
        if sid not in api.sids: return
        sess = api.sids[sid]
        queue: Queue = sess["queue"]

        h, waited_seconds = DownCore._download_handle(sess), 0
        try:
            for i in h:
                sess["is_waiting"] = True
                sess["progress"] = i
                waited_seconds = 0
                while True:
                    try:
                        queue.get(timeout=1)
                    except Empty:
                        pass
                    else:
                        break
                    waited_seconds += 1
                    if waited_seconds > 60 * 10:
                        sess["ended_time"] = time.time()
                        sess["error"] = "timeout"
                        return
            else:
                with api.lock:
                    sess["progress"] = sess["totalStep"]
                    sess["ended_time"] = time.time()
                    sess["finished"] = True
        except Exception as e:
            sess["ended_time"] = time.time()
            sess["error"] = str(e.args)
