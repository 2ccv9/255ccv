import logging
import os
import random
from ast import literal_eval

import requests
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse

loger = logging.getLogger(__name__)

uas = tuple({
    "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:106.0) Gecko/20100101 Firefox/106.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:100.0) Gecko/20100101 Firefox/100.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:112.0) Gecko/20100101 Firefox/112.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/114.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/112.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/111.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/109.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:108.0) Gecko/20100101 Firefox/108.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:107.0) Gecko/20100101 Firefox/107.0",
})

requests_session = requests.Session()
requests_session.verify = False
requests_session.trust_env = False
requests_session.headers.update({
    "User-Agent": random.choice(uas),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "DNT": "1",
    "Sec-GPC": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Priority": "u=0, i",
})


class down:

    @staticmethod
    def cover(request: WSGIRequest, rid: str):
        from api import models
        d = models.Resolve.objects.get(rid=rid)
        j = literal_eval(d.data)

        _test_file = "hqdefault.webp"
        if os.path.isfile(_test_file):
            with open(_test_file, "rb") as f:
                return HttpResponse(f.read(), content_type="image/jpeg")

        rd = None
        for i in j["thumbnails"][:3]:
            try:
                loger.info(f"downloading cover: {i['url']}")
                rd = requests_session.get(i["url"], timeout=5, allow_redirects=True, )
                if rd.status_code == 200:
                    return HttpResponse(rd.content, content_type="image/jpeg")
            except Exception as e:
                loger.info(str(e))
        else:
            if rd: loger.info(f"cover status code is {rd.status_code}")
        return HttpResponse(status=500)

    @staticmethod
    def video(request: WSGIRequest, name: str):
        # cdn = request.GET.get("cdn", default=None)
        # if not cdn: cdn = "no"
        # if cdn not in ("no", "cf", "gcore",): return JsonResponse({}, status=400)
        from common.config import CONFIG
        path = f"/static/video/{name}"
        # if cdn == "no":
        #     return redirect(CONFIG["direct_download_link_prefix"] + path, permanent=True)
        # elif cdn == "cf":
        #     return redirect(CONFIG["cf_cdn_download_link_prefix"] + path, permanent=True)
        # elif cdn == "gcore":
        #     return redirect(CONFIG["gcore_cdn_download_link_prefix"] + path, permanent=True)
        return redirect(path, permanent=True)
