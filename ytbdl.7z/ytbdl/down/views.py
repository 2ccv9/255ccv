import logging
import os
import random
from ast import literal_eval

import requests
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse

import common.utils

loger = logging.getLogger(__name__)

uas = tuple({
    "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:106.0) Gecko/20100101 Firefox/106.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:100.0) Gecko/20100101 Firefox/100.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0",
    "Mozilla/5.0 (Windows NT 10.0; rv:112.0) Gecko/20100101 Firefox/112.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/114.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/112.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/111.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/109.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:108.0) Gecko/20100101 Firefox/108.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:107.0) Gecko/20100101 Firefox/107.0",
})

requests_session = requests.Session()
requests_session.verify = False
requests_session.trust_env = False
requests_session.headers.update({
    "User-Agent": random.choice(uas),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "DNT": "1",
    "Sec-GPC": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Priority": "u=0, i",
})


class down:

    @staticmethod
    def cover(request: WSGIRequest, rid: str):
        from api import models
        d = models.Resolve.objects.get(rid=rid)
        j = literal_eval(d.data)

        from ytbdl import settings
        _test_file = "./resource/test_down_cover.webp"
        if os.path.isfile(_test_file) and settings.DEBUG:
            with open(_test_file, "rb") as f:
                return HttpResponse(f.read(), content_type="image/jpeg")

        rd = None
        for i in j["thumbnails"][:3]:
            try:
                loger.info(f"downloading cover: {i['url']}")
                rd = requests_session.get(i["url"], timeout=5, allow_redirects=True, )
                if rd.status_code == 200:
                    return HttpResponse(rd.content, content_type="image/jpeg")
            except Exception as e:
                loger.info(str(e))
        else:
            if rd: loger.info(f"cover status code is {rd.status_code}")
        return HttpResponse(status=500)

    @staticmethod
    def subtitle(request: WSGIRequest, name: str):
        rid = request.GET.get("rid", default=None)
        key = request.GET.get("key", default=None)
        if not rid: return JsonResponse({}, status=400)
        if not key: return JsonResponse({}, status=400)
        from api import models
        d = models.Resolve.objects.get(rid=rid)
        j = literal_eval(d.data)

        data = None
        from ytbdl import settings
        _test_file = "./resource/test_down_subtitle.vtt"
        if os.path.isfile(_test_file) and settings.DEBUG:
            with open(_test_file, "rb") as f:
                data = f.read()
        else:
            rd = None
            for i in j["_subtitles"]:
                if i["key"] != key or i["url"] is None: continue
                try:
                    loger.info(f"downloading subtitle: {i['key']} {i['url']}")
                    rd = requests_session.get(i["url"], timeout=5, allow_redirects=True, )
                    if rd.status_code == 200:
                        data = rd.content
                        break
                except Exception as e:
                    loger.info(str(e))
            else:
                if rd: loger.info(f"subtitle status code is {rd.status_code}")

        if data is None: return HttpResponse(status=500)
        v = common.utils.vtt_2_srt(common.utils.chardet_decode(data))
        if not v[0]: return HttpResponse(v[1], status=500)
        return HttpResponse(v[1], content_type="application/octet-stream")

    @staticmethod
    def video(request: WSGIRequest, name: str):
        # cdn = request.GET.get("cdn", default=None)
        # if not cdn: cdn = "no"
        # if cdn not in ("no", "cf", "gcore",): return JsonResponse({}, status=400)
        from common.config import CONFIG
        params = request.GET.urlencode()
        path = f"/static/video/{name}?{params}"
        # print(path, params)
        # if cdn == "no":
        #     return redirect(CONFIG["direct_download_link_prefix"] + path, permanent=False)
        # elif cdn == "cf":
        #     return redirect(CONFIG["cf_cdn_download_link_prefix"] + path, permanent=False)
        # elif cdn == "gcore":
        #     return redirect(CONFIG["gcore_cdn_download_link_prefix"] + path, permanent=False)
        return redirect(path, permanent=False)
