import base64
import datetime
import functools
import os
import string, random
import hashlib
import aiofiles
import asyncio
import chardet
import pytz
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse
from django.contrib.auth import authenticate
from pathlib import Path
import os


def get_user(request: WSGIRequest):
    from api import models
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Basic '):
        try:
            base64_credentials = auth_header.split(' ')[1]
            credentials = base64.b64decode(base64_credentials).decode('utf-8')
            username, password_hash = credentials.split(':', 1)
            user = models.User.objects.filter(uid=username, password_hash=password_hash).first()
            if user is not None and not user.disabled: return user
        except (IndexError, ValueError):
            pass
    return None


def get_admin(request: WSGIRequest):
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Basic '):
        try:
            base64_credentials = auth_header.split(' ')[1]
            credentials = base64.b64decode(base64_credentials).decode('utf-8')
            username, password = credentials.split(':', 1)
            user = authenticate(username=username, password=password)
            if user is not None: return user
        except (IndexError, ValueError):
            pass
    return None


def decorator__auth_user(func):
    @functools.wraps(func)
    def wrapper(request, *args, **kwargs):
        user = get_user(request)
        if user is None: return HttpResponse("Invalid credentials.", status=401)
        result = func(user, request, *args, **kwargs)
        return result

    return wrapper


def decorator__auth_admin(func):
    @functools.wraps(func)
    def wrapper(request, *args, **kwargs):
        admin = get_admin(request)
        if admin is None: return HttpResponse("Invalid credentials.", status=401)
        result = func(admin, request, *args, **kwargs)
        return result

    return wrapper


def decorator__auth_any(func):
    @functools.wraps(func)
    def wrapper(request: WSGIRequest, *args, **kwargs):
        user = get_user(request)
        admin = get_admin(request)
        if user is None and admin is None: return HttpResponse("Invalid credentials.", status=401)
        if user is None:
            uid = request.GET.get("uid", None)  # from admin view
            if uid is not None:
                from api import models
                user = models.User.objects.filter(uid=uid)
                if user.exists():
                    user = user.first()
        result = func(user, admin, request, *args, **kwargs)
        return result

    return wrapper


# 生成随机ID
def generate_random_id(length):
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


def convert_to_china_datetime(utc_time):
    if isinstance(utc_time, str):
        try:
            utc_time = datetime.datetime.strptime(utc_time, "%Y-%m-%dT%H:%M:%S.%fZ")
        except:
            utc_time = datetime.datetime.strptime(utc_time, "%Y-%m-%dT%H:%M:%SZ")
        utc_time = utc_time.replace(tzinfo=datetime.timezone.utc)
    target_timezone = pytz.timezone('Asia/Shanghai')
    target_time = utc_time.replace(tzinfo=pytz.utc).astimezone(target_timezone)
    return target_time


# 速度格式转换
def bytes_2_bkmgt(bytes, o=None):
    if o is None:
        o = ['b', 'kb', 'mb', 'gb', 'tb', 'pb', 'eb', 'zb', 'yb', 'bbb']
    if bytes > 1000 and len(o) > 1:  # 高单位
        o.pop(0)
        return bytes_2_bkmgt(bytes / 1000, o)
    else:  # 当前单位
        if o[0] == 'b':
            return str(int(bytes)) + o[0]
        elif o[0] == 'kb':
            v = round(bytes, 1)
            if v >= 100:
                return str(int(v)) + o[0]  # # kb数值大于100时不显示小数，mb大于2时只显示一位小数
            else:
                return str(v) + o[0]
        else:
            v = round(bytes, 2)
            if v >= 2:
                return str(round(v, 1)) + o[0]
            else:
                return str(v) + o[0]


def fsync(f):
    f.flush()
    os.fsync(f.fileno())


async def afsync(f):
    await f.flush()
    os.fsync(f.fileno())


# 字节解码
def chardet_decode(by):
    for e in chardet.detect_all(by):
        try:
            return by.decode(e['encoding'])
        except Exception:
            pass
    else:
        return by.decode('utf8', errors='ignore')


# list转str
def tostr(*args):
    return " ".join(map(lambda x: str(x), args))


# 计算文件hash
def calculate_file_hash(filename):
    chunk_size = 65536
    hasher = hashlib.sha1()
    n = 0
    with open(filename, mode='rb') as file:
        while True:
            chunk = file.read(chunk_size)
            if len(chunk) == 0:
                break
            n += len(chunk)
            hasher.update(chunk)
    return n, hasher.hexdigest()


# 获取服务储存文件可用的空间
def get_free_space(real=False):
    from common.config import BASE_DIR
    a = os.statvfs(BASE_DIR)
    # state["disk_free_size"] = a.f_bsize * a.f_bavail
    # state["disk_total_size"] = a.f_bsize * a.f_blocks
    if real:
        v = a.f_bsize * a.f_bavail
    else:
        _last = 0.5 * 1024 * 1024 * 1024  # 保留0.5g
        v = (a.f_bsize * a.f_bavail) - _last
    if v < 0:   v = 0
    return v


# 磁盘总空间
def get_total_space():
    from common.config import BASE_DIR
    a = os.statvfs(BASE_DIR)
    return a.f_bsize * a.f_blocks


def get_folder_size(folder_path):
    return sum(f.stat().st_size for f in Path(folder_path).rglob('*') if f.is_file())
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(folder_path):
        for filename in filenames:
            file_path = os.path.join(dirpath, filename)
            # 排除符号链接
            if os.path.isfile(file_path):
                total_size += os.path.getsize(file_path)
    return total_size
