import json
import os
import socket
import sys
import traceback, logging
from pathlib import Path

import common
from common import utils, enum
from common.utils import chardet_decode

import logging

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "db"
CONFIG_PATH = DB_PATH / "config.json"
NO_CONFIG = False  # 测试阶段不创建配置文件

_default_config = {
    "log_level": "INFO",  # 日志等级：DEBUG INFO WARN
    "homepage_link": "https://ytbdl.undo.it",
    "direct_download_link_prefix": "https://no-cdn.ytbdl.undo.it",
    "cf_cdn_download_link_prefix": "",
    "gcore_cdn_download_link_prefix": "https://gcore-cdn.ytbdl.undo.it",

}


class GlobalConfig(dict):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        super().__init__()
        self.sys_argv = []  # 记录原始执行参数
        self.update(_default_config)

    # 配置文件版本迁移
    def upgrade(self):
        if "UWSGI_ORIGINAL_PROC_NAME" not in os.environ:
            self["listen"] = "0.0.0.0"
            listen_port = 7788
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            try:
                sock.connect(("127.0.0.1", listen_port))
                listen_port = 17788
            except Exception:
                pass
            sock.close()
            self["listen_port"] = listen_port

        self["direct_download_link_prefix"] = self["direct_download_link_prefix"].rstrip("/")
        self["cf_cdn_download_link_prefix"] = self["cf_cdn_download_link_prefix"].rstrip("/")

    # 加载配置文件
    def load(self):
        if not os.path.isdir(DB_PATH):
            os.mkdir(DB_PATH)
        if not os.path.isfile(CONFIG_PATH):
            if not NO_CONFIG:
                self.pop("listen", None)
                self.pop("listen_port", None)
                with open(CONFIG_PATH, 'w', encoding="utf8") as f:
                    f.write(json.dumps(self, ensure_ascii=False, indent=2))
                    utils.fsync(f)
        else:
            with open(CONFIG_PATH, 'rb') as f:
                text = chardet_decode(f.read())
                if text.startswith(u'\ufeff'):  text = text[3:]
                try:
                    self.update(json.loads(text))
                except Exception:
                    logger.error(f"Loading config failed.")
                    logger.error(CONFIG_PATH)
                    logger.error(traceback.format_exc())
                    os._exit(-4)
        self.upgrade()

    # 保存配置文件
    def save(self):
        if not NO_CONFIG:
            logger.warning(f"Saving config to {CONFIG_PATH}.")
            with open(CONFIG_PATH, 'w', encoding="utf8") as f:
                f.write(json.dumps(self, ensure_ascii=False, indent=2))
                utils.fsync(f)


# 配置文件对象,单例
CONFIG = GlobalConfig()
