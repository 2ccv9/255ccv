import enum
import re


# 常用的正则表达式
class Regex:
    sub__user_id = re.compile(r"[^\w]+")
