#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import copy, re
import os
import secrets
import shutil
import sys
import logging
import threading
import time
import psutil


def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ytbdl.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


def init():
    # threading.Thread(target=list_open_files, daemon=True, ).start()
    from common.config import CONFIG
    CONFIG.load()
    CONFIG.sys_argv.extend(sys.argv)
    sys.argv = [sys.argv[0], "runserver",
                f"{CONFIG['listen']}:{CONFIG['listen_port']}",
                "--noreload", "--no-color",
                ]
    # if "debug" not in CONFIG.sys_argv: # django 4+
    #     sys.argv.append("--skip-checks")


def ignore_files_and_dirs(dir, contents):
    ignore_list = []
    for item in contents:
        if item in ['__pycache__', "migrations", ]:
            ignore_list.append(item)
        elif item.endswith(".proto"):
            ignore_list.append(item)
    return ignore_list


if __name__ == '__main__':
    cwd = os.path.abspath(os.path.dirname(__file__))
    _p = {
        "common",
        "manage.py",
        "requirements.txt",
        "ytbdl",
        "resource",
        "static",
        # 项目
        "api",
        "down",
        "app",
    }
    migrations = [
        "api",
    ]
    if "new_secret_key" in sys.argv:
        from django.core.management.utils import get_random_secret_key

        new_key = None
        file = os.path.join(cwd, "ytbdl", "settings.py")
        with open(file, "r", encoding="utf8") as f:
            fr = f.read()
            while True:
                try:
                    new_key = get_random_secret_key()
                    v = re.sub(r"(\nSECRET_KEY\s=\s\")[^\"]+", rf'\1{new_key}', fr, 1)
                    break
                except re.error:
                    pass
            with open(file, "w", encoding="utf8") as f2:
                f2.write(v)
            print("Successfully changed the key to", new_key)
    elif "package" in sys.argv:  # 生成用于部署的源码包
        output_dir = os.path.join(cwd, "output", "ytbdl")
        if os.path.isdir(output_dir): shutil.rmtree(output_dir, )
        os.makedirs(output_dir)
        for i in list(_p):
            _from = os.path.join(cwd, i)
            print(f"Copy: {_from}")
            if os.path.isdir(_from):
                shutil.copytree(_from, os.path.join(output_dir, i), ignore=ignore_files_and_dirs)
            else:
                shutil.copy(_from, os.path.join(output_dir, i))
        _cf_map = [
            (os.path.join(output_dir, "resource", "ytbdl.conf"),
             re.compile(r"\s{2}(listen\s7788\s)"), "  # " + r'\1'),
            # (os.path.join(output_dir, "common", "config.py"), re.compile(r"0\.0\.0\.0"), r"127.0.0.1"),
            (os.path.join(output_dir, "common", "config.py"), re.compile(r"(\nNO_CONFIG\s=\s)True"), r'\1' + "False"),
            (os.path.join(output_dir, "ytbdl", "settings.py"),
             re.compile(r"(\nDEBUG\s=\s)True"), r'\1' + "False"),
        ]
        for _file, _re, _rp in _cf_map:
            with open(_file, "r", encoding="utf8") as f:
                v = re.sub(_re, _rp, f.read(), 1)
                with open(_file, "w", encoding="utf8") as f2: f2.write(v)

        print(f"ok.")
    elif "backupmigrations" in sys.argv:  # 备份数据库迁移记录
        for i in migrations:
            path1 = os.path.join(cwd, i, "migrations")
            path2 = os.path.join(cwd, "db", "backupmigrations", i, "migrations", )
            if os.path.isdir(path1):
                if os.path.isdir(path2): shutil.rmtree(path2)
                if not os.path.isdir(os.path.split(path2)[0]): os.makedirs(os.path.split(path2)[0])
                print(f"Copyto: {os.path.split(path2)[0]}")
                shutil.copytree(path1, path2, ignore=ignore_files_and_dirs)
    elif "recovermigrations" in sys.argv:  # 恢复数据库迁移记录
        for i in migrations:
            path1 = os.path.join(cwd, i, "migrations", )
            path2 = os.path.join(cwd, "db", "backupmigrations", i, "migrations", )
            if os.path.isdir(path2):
                if not os.path.isdir(path1): os.makedirs(path1)
                print(f"Copyto: {path1}")
                for j in os.listdir(path2):
                    if os.path.isfile(os.path.join(path2, j, )):
                        shutil.copy(os.path.join(path2, j, ), os.path.join(path1, j, ), )
    elif "delete_source_code" in sys.argv:  # 手动更新时删除旧版文件
        v = input("Delete source code files? (Y/n) ")
        if v.lower() != "y":
            print("Canceled.")
        else:
            for i in list(_p):
                _from = os.path.join(cwd, i)
                print(f"Delete: {_from}")
                if os.path.isdir(_from):
                    shutil.rmtree(_from)
                elif os.path.isfile(_from):
                    os.remove(_from)
            print(f"Finished.")
    else:
        for i in ("-h", "--help", "help",
                  "makemigrations", "migrate", "createsuperuser", "startapp", "collectstatic",
                  "showmigrations", "shell",
                  ):
            if i in sys.argv: break
        else:
            init()
        main()
    sys.exit(0)
