const msgbox_info = document.querySelector("#msgbox-info")
const msgbox_info_ok = msgbox_info.querySelector("button")
const msgbox_info_text = msgbox_info.querySelector("#msgbox-info-text")

const msgbox_link = document.querySelector("#msgbox-link")
const msgbox_link_ok = msgbox_link.querySelector("button")
const msgbox_link_t1 = msgbox_link.querySelector("#msgbox-link-t1")
const msgbox_link_l1 = msgbox_link.querySelector("#msgbox-link-l1")
const msgbox_link_l1_span = msgbox_link_l1.querySelector("span")
const msgbox_link_t2 = msgbox_link.querySelector("#msgbox-link-t2")
const msgbox_link_l2 = msgbox_link.querySelector("#msgbox-link-l2")
const msgbox_link_l2_span = msgbox_link_l2.querySelector("span")
const msgbox_link_t3 = msgbox_link.querySelector("#msgbox-link-t3")
const msgbox_link_l3 = msgbox_link.querySelector("#msgbox-link-l3")
const msgbox_link_l3_span = msgbox_link_l3.querySelector("span")

// msgbox_link.style.display = "flex"

const msgbox_pending = document.querySelector("#msgbox-pending")
const msgbox_pending_img = msgbox_pending.querySelector("#msgbox-pending-img")
const msgbox_pending_text = msgbox_pending.querySelector("#msgbox-pending-text")

const url_input_container = document.querySelector("#url-input-container")
const url_input = url_input_container.querySelector("#url-input")
const url_input_enter = url_input_container.querySelector("#url-input-enter")

const detail = document.querySelector("#detail")
const detail_qualities = document.querySelector("#detail-qualities")
const detail_image = detail.querySelector("#detail-image")
const detail_head_title = detail.querySelector("#detail-head strong")
const detail_other_date = detail.querySelector("#detail-other-date")
const detail_other_desc = detail.querySelector("#detail-other-desc")


detail.style.display = "none"


const res = [/youtube\.com\/watch\?v=([\w\-]+)\/?/i, /^([\w\-]+)$/i,]

function checkUrl(text) {
    text = text ?? ""
    if (text.length === 0) return true;
    for (const re of res) {
        // console.log(re, text)
        if (re.test(text)) {
            return true;
        }
    }
    return false;
}

url_input_container.addEventListener("click", (event) => {
    if (url_input !== document.activeElement) {
        url_input.focus()
    }
})
url_input.addEventListener("input", (event) => {
    url_input.value = url_input.value.replace(/[\r\s\t\n]+/g, '');

    clearVideoInfo()

    if (!checkUrl(url_input.value)) {
        // url_input.style.color = "#FF816F"
        url_input.style.border = "0px #FF6262 dotted"
        url_input.style.borderBottomWidth = "2px"
    } else {
        url_input.style.color = "#FFFFFF"
        url_input.style.border = "none"
    }
})

url_input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        url_input_enter.click()
    }
})

url_input_enter.addEventListener("click", (event) => {
    let ok = false, text = url_input.value;
    for (const re of res) {
        const mr = text.match(re)
        if (mr) {
            text = mr[1];
            ok = true;
            break;
        }
    }
    if (!ok) {
        msgbox_info_text.textContent = ":( Invalid URL."
        msgbox_info.style.display = "flex"
        return;
    }
    msgbox_pending_text.textContent = `Resolving... (${text})`
    msgbox_pending.style.display = "flex"
    clearVideoInfo()
    resolveVideo(text)
})

msgbox_info_ok.addEventListener("click", (event) => {
    msgbox_info.style.display = "none"
})
msgbox_link_ok.addEventListener("click", (event) => {
    msgbox_link.style.display = "none"
})

async function resolveVideo(vid) {
    let data;
    try {
        const url = new URL(window.location.href.replace(/#$/, ""));
        url.pathname = "/api/resolve"
        url.searchParams = new URLSearchParams()
        url.searchParams.set("vid", vid)
        const response = await fetch(url.href, {
            method: "GET", headers: {
                "Content-Type": "application/json",
            }, // body: JSON.stringify({
            //     vid: vid,
            // }),
        });
        console.log("resolveVideo:response", response);
        if (!response.ok) {
            throw new Error(`the status code is ${response.status} instead of 200`);
        }
        data = await response.json();
    } catch (error) {
        console.error(error);
        msgbox_info_text.textContent = error.toString()
        msgbox_info.style.display = "flex"
    }
    msgbox_pending.style.display = "none"
    if (data) {
        await showVideoInfo(data)
    }
}

function clearVideoInfo() {
    detail.style.display = "none"
    detail_head_title.textContent = ""
    detail_other_date.textContent = ""
    detail_other_desc.textContent = ""
    detail_image.src = ""
    detail_qualities.innerHTML = ""
}

async function showVideoInfo(data) {
    clearVideoInfo()
    detail_head_title.textContent = data["title"]
    detail_other_date.textContent = formatTimestamp(data["timestamp"], 'YYYY-MM-DD HH:mm')
    detail_other_desc.textContent = data["description"]
    detail_image.src = `/download/cover/${data["rid"]}`

    detail.style.display = "flex"

    detail.video_info = data

    for (const q of data["qualities"]) {
        const htmlTemplate = `
<div class="detail-quality-item">
    <div>
        <span class="widthxheight">${q["width"]}x${q["height"]}</span>
        <span>|</span>
        <span>${parseInt(q["size"], 10) === 1 ? "Unknown" : formatBytes(parseInt(q["size"], 10))}</span>
        <span>|</span>
        <span>${q["cached"] ? "Cached" : q["type"] === "va" ? `Fast` : `${q["video_ext"]}+audio`}</span>
        <span></span>
        <button class="info">Info</button>
        <button class="download">Download</button>
    </div>
    <div class="underline"></div>
</div>
`;
        detail_qualities.insertAdjacentHTML('beforeend', htmlTemplate);
        let item = detail_qualities.querySelector('.detail-quality-item:last-child');
        item.quality_info = q;
        let info_button = item.querySelector(".info")
        info_button.addEventListener('click', (event) => {
            console.log(detail.video_info, item.quality_info)
            msgbox_pending_text.textContent = `Fetching... (${item.querySelector(".widthxheight").textContent})`
            msgbox_pending.style.display = "flex"
            getQualityInfo(detail.video_info, item.quality_info)
        })
        let download_button = item.querySelector(".download")
        download_button.addEventListener('click', (event) => {
            // console.log(detail.video_info, item.quality_info)
            msgbox_pending_text.textContent = `[0/0] Requesting... (${item.querySelector(".widthxheight").textContent})`
            msgbox_pending.style.display = "flex"
            downloadVideo(detail.video_info, item.quality_info)
        })
    }
}

async function getQualityInfo(video_info, quality_info) {
    let data;
    try {
        const url = new URL(window.location.href.replace(/#$/, ""));
        url.pathname = "/api/quality"
        url.searchParams = new URLSearchParams()
        url.searchParams.set("rid", video_info["rid"])
        url.searchParams.set("qid", quality_info["qid"])
        const response = await fetch(url.href, {
            method: "GET", headers: {
                "Content-Type": "application/json",
            },
        });
        console.log("getQualityInfo:response", response);
        if (!response.ok) {
            throw new Error(`the status code is ${response.status} instead of 200`);
        }
        data = await response.json();
        if (data["error"]) {
            throw new Error(data["error"]);
        }
    } catch (error) {
        console.error(error);
        msgbox_info_text.textContent = error.toString()
        msgbox_info.style.display = "flex"
        msgbox_pending.style.display = "none"
        return;
    }
    showLink(data);
    msgbox_pending.style.display = "none"
}

async function downloadVideo(video_info, quality_info) {
    let data;
    try {
        const url = new URL(window.location.href.replace(/#$/, ""));
        url.pathname = "/api/download"
        url.searchParams = new URLSearchParams()
        url.searchParams.set("rid", video_info["rid"])
        url.searchParams.set("qid", quality_info["qid"])
        const response = await fetch(url.href, {
            method: "GET", headers: {
                "Content-Type": "application/json",
            },
        });
        console.log("downloadVideo:response", response);
        if (!response.ok) {
            throw new Error(`the status code is ${response.status} instead of 200`);
        }
        data = await response.json();
        if (data["error"]) {
            throw new Error(data["error"]);
        }
    } catch (error) {
        console.error(error);
        msgbox_info_text.textContent = error.toString()
        msgbox_info.style.display = "flex"
        msgbox_pending.style.display = "none"
        return;
    }
    if (data["cached"]) {
        showLink(data);
        msgbox_pending.style.display = "none"
        return;
    }

    await sleep(1000);
    await checkProgress(data["sid"])
}

async function checkProgress(sid) {
    while (true) {
        let data;
        let goout = false;
        try {
            const url = new URL(window.location.href.replace(/#$/, ""));
            url.pathname = "/api/progress"
            url.searchParams = new URLSearchParams()
            url.searchParams.set("sid", sid)
            const response = await fetch(url.href, {
                method: "GET", headers: {
                    "Content-Type": "application/json",
                },
            });
            console.log("checkProgress:response", response);
            if (!response.ok) {
                goout = true;
                throw new Error(`the status code is ${response.status} instead of 200`);
            }
            data = await response.json();
            if (data["error"].length > 0) {
                goout = true;
                throw new Error(data["error"]);
            }
        } catch (error) {
            console.error(error);
            if (goout) {
                msgbox_info_text.textContent = error.toString()
                msgbox_info.style.display = "flex"
                msgbox_pending.style.display = "none"
                break;
            }
            await sleep(2000);
            continue;
        }
        const sw = `[${data["progress"]}/${data["totalStep"]}]`
        if (data["progress"] === 0) {
            msgbox_pending_text.textContent = `${sw} Preparing...`
            await sleep(2000);
        } else if (data["progress"] === 1) {
            msgbox_pending_text.textContent = `${sw} Downloading video... (${formatBytes(data["downspeed_video"] + data["downspeed_audio"])}/s, ${formatBytes(data["downpart_video"] + data["downpart_audio"])}/${formatBytes(data["filesize_video"] + data["filesize_audio"])})`
            await sleep(3000);
        } else if (data["progress"] === 2) {
            msgbox_pending_text.textContent = `${sw} Downloading audio... (${formatBytes(data["downspeed_video"] + data["downspeed_audio"])}/s, ${formatBytes(data["downpart_video"] + data["downpart_audio"])}/${formatBytes(data["filesize_video"] + data["filesize_audio"])})`
            await sleep(3000);
        } else if (data["progress"] === 3) {
            msgbox_pending_text.textContent = `${sw} Finalizing...`
            await sleep(2000);
        } else if (data["progress"] === 4) {
            showLink(data);
            msgbox_pending.style.display = "none"
            break;
        }
        msgbox_pending.style.display = "flex"
    }

}

function showLink(data) {
    if ("video_link" in data) {
        msgbox_link_t1.textContent = `- Video: ${data["width"]}x${data["height"]}, ${data["video_ext"]}, ${parseInt(data["video_size"], 10) === 1 ? "Unknown" : formatBytes(parseInt(data["video_size"], 10))}`
        msgbox_link_l1_span.textContent = msgbox_link_l1.href = data["video_link"]
        if ("audio_link" in data) {
            msgbox_link_t1.textContent = `- Only video: ${data["width"]}x${data["height"]}, ${data["video_ext"]}, ${parseInt(data["video_size"], 10) === 1 ? "Unknown" : formatBytes(parseInt(data["video_size"], 10))}`
            msgbox_link_t2.textContent = `- Only audio: ${data["audio_ext"]}, ${formatBytes(parseInt(data["audio_size"], 10))}`
            msgbox_link_l2_span.textContent = msgbox_link_l2.href = data["audio_link"]
            msgbox_link_t2.style.display = "block"
            msgbox_link_l2.style.display = "block"
        } else {
            msgbox_link_t2.style.display = "none"
            msgbox_link_l2.style.display = "none"
        }
        msgbox_link_t1.style.display = "block"
        msgbox_link_l1.style.display = "block"
        msgbox_link_t3.style.display = "none"
        msgbox_link_l3.style.display = "none"
    } else {
        msgbox_link_t1.textContent = "- Download link (Direct, Usually fastest):"
        msgbox_link_t2.textContent = "- Download link (Cloudflare CDN):"
        msgbox_link_t3.textContent = "- Download link (Gcore CDN):"
        if (data["download_link_direct"]) {
            msgbox_link_t1.style.display = "block"
            msgbox_link_l1.style.display = "block"
            msgbox_link_l1_span.textContent = msgbox_link_l1.href = data["download_link_direct"]
        } else {
            msgbox_link_t1.style.display = "none"
            msgbox_link_l1.style.display = "none"
        }
        if (data["download_link_cf_cdn"]) {
            msgbox_link_l2_span.textContent = msgbox_link_l2.href = data["download_link_cf_cdn"]
            msgbox_link_t2.style.display = "block"
            msgbox_link_l2.style.display = "block"
        } else {
            msgbox_link_t2.style.display = "none"
            msgbox_link_l2.style.display = "none"
        }
        if (data["download_link_gcore_cdn"]) {
            msgbox_link_l3_span.textContent = msgbox_link_l3.href = data["download_link_gcore_cdn"]
            msgbox_link_t3.style.display = "block"
            msgbox_link_l3.style.display = "block"
        } else {
            msgbox_link_t3.style.display = "none"
            msgbox_link_l3.style.display = "none"
        }
    }
    msgbox_link.style.display = "flex"
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function formatTimestamp(timestamp, format) {
    const date = new Date((timestamp + (8 * 60 * 60)) * 1000);
    const map = {
        'YYYY': date.getUTCFullYear(),
        'MM': String(date.getUTCMonth() + 1).padStart(2, '0'),
        'DD': String(date.getUTCDate()).padStart(2, '0'),
        'HH': String(date.getUTCHours()).padStart(2, '0'),
        'mm': String(date.getUTCMinutes()).padStart(2, '0'),
        'ss': String(date.getUTCSeconds()).padStart(2, '0')
    };
    return format.replace(/YYYY|MM|DD|HH|mm|ss/g, matched => map[matched]);
}

function formatBytes(bytes) {
    if (bytes === 0) return "0 B";
    const sizes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    let formattedSize = (bytes / Math.pow(1024, i)).toFixed(1);
    if (formattedSize % 1 === 0) formattedSize = parseInt(formattedSize);
    return `${formattedSize} ${sizes[i]}`;
}

