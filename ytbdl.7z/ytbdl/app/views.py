from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse
from django.shortcuts import render


class app:
    def __call__(self, request: WSGIRequest, ):
        # print(request.scheme, request.is_secure())
        return render(request, "index.html", {"request": request})
